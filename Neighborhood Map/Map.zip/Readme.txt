Neighborhood Map Project

This project about menouf city and it's important places.

* How to run the app:

1- download the zip file.
2- unzip the file.
3- run the index.html.
4- open the map and search as you want.
 